-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 3.36.63.119    Database: god_life
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `fine_immunity_count` int NOT NULL DEFAULT '0',
  `latitude_setting` double DEFAULT NULL,
  `longitude_setting` double DEFAULT NULL,
  `mileage` int NOT NULL DEFAULT '0',
  `role` tinyint DEFAULT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `modified_date` datetime(6) DEFAULT NULL,
  `personal_id` bigint DEFAULT NULL,
  `social_id` bigint DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `home_name` varchar(255) DEFAULT NULL,
  `main_account_no` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) NOT NULL,
  `profile_imageurl` varchar(255) DEFAULT NULL,
  `user_key` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8in84v29449buuskcor7ina9m` (`personal_id`),
  CONSTRAINT `FK8in84v29449buuskcor7ina9m` FOREIGN KEY (`personal_id`) REFERENCES `personal` (`id`),
  CONSTRAINT `member_chk_1` CHECK ((`role` between 0 and 1))
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (2,37.5006744185994,127.03646946847,976050,0,'2024-10-07 10:16:02.002649',1,'2024-10-10 14:06:18.569045',3,3716715726,'rlarbfla1212@naver.com','서울 강남구 역삼동 804','9996629768584346','김규림','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg','bebfb817-d8ba-4c3c-9322-e1126c0f3a3a'),(0,37.676305855958404,126.7675724894472,100,0,'2024-10-07 10:17:25.332291',4,'2024-10-11 09:32:47.088904',2,3718289079,'dpsjh@naver.com','경기 고양시 일산서구 일산동 1086','9993738915524664','송주한','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg','2dceb1d1-5157-478e-b429-fe80c5f49265'),(0,37.5006744185994,127.03646946847,50,0,'2024-10-07 10:38:06.707342',5,'2024-10-11 09:21:59.965161',1,3721125326,'thdckdyd123@naver.com','서울 강남구 역삼동 804','9994357242541240','송창용','http://k.kakaocdn.net/dn/Lrhqj/btsJKcn4wPI/GLofO5RcqN2BMTxdyTnCfk/img_640x640.jpg','138a680b-cfd5-41fc-932a-71e4531a2e54'),(0,37.49773012417759,127.02929950278187,100,0,'2024-10-07 16:15:08.829246',7,'2024-10-11 09:32:44.584870',25,3722262497,'namid0711@naver.com','서울 강남구 역삼동 825-20','9994345113518020','박진우','http://k.kakaocdn.net/dn/xCiRC/btsDqi2KAUa/5VzV5K09tiCKWuAyQuaCzk/img_640x640.jpg','6a3c9eaa-c2e1-451c-b09e-3768e22a8413'),(3,37.5250892160129,126.947545050571,1050,0,'2024-10-08 17:48:59.160579',40,'2024-10-11 11:22:14.179223',26,3685044059,'ktk3939@naver.com','서울 영등포구 여의도동','9998479616698211','강태경','http://k.kakaocdn.net/dn/bHrw08/btsJm69rhr8/bKlE79wgOsFTysxAnkRqC0/img_640x640.jpg','bc216ae2-56a3-45ef-bb8c-b257ecd53cfb'),(0,36.0003726030301,129.359387285494,200,0,'2024-10-10 17:12:46.295302',70,'2024-10-11 09:03:02.130375',23,3703883149,'cvcvcx@naver.com','경북 포항시 남구 연일읍 오천리 92-1','9990490624965086','조창훈','http://k.kakaocdn.net/dn/rERkR/btsGd0Mqrif/CxbmM1KN4M6skrf50qaT40/img_640x640.jpg','b2ac6430-6d38-424d-84b5-ac10a8e07f97');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11 11:38:39
